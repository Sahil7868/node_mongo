var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var mongoose= require('mongoose');

app.use(bodyParser.json());

Genre=require('./models/genres');

Book=require('./models/books');

User=require('./models/users');

mongoose.connect('mongodb://localhost/bookstore');

var db=mongoose.connection;

app.get('/', function(req,res){

res.send("hello cello");

});

app.get('/api/genres',function(req,res){

    Genre.getGenre(function(err,result){
        if(err)
        {
            throw err;
        }
        else
        {
            res.json(result);
        }

    });

});
app.post('/api/genres',function(req,res){

var genrebody=req.body;
    Genre.addGenre(genrebody,function(err,result){
        if(err)
        {
            throw err;
        }
        else
        {
            res.json(result);
        }

    });

});
app.put('/api/genres/:_id',function(req,res){
var id=req.params._id;
var genrebody=req.body;
    Genre.updateGenre(id,genrebody,{},function(err,result){
        if(err)
        {
            throw err;
        }
        else
        {
            res.json(result);
        }

    });

});
app.delete('/api/genres/:_id',function(req,res){
var id=req.params._id;

    Genre.deleteGenre(id,function(err,result){
        if(err)
        {
            throw err;
        }
        else
        {
            res.json(result);
        }

    });

});

app.get('/api/users',function(req,res){

    User.getUser(function(err,result){
        if(err)
        {
            throw err;
        }
        else
        {
            res.json(result);
        }

    });

});

app.get('/api/books',function(req,res){

    Book.getbooks(function(err,result){
        if(err)
        {
            throw err;
        }
        else
        {
            res.json(result);
        }

    });

});
app.get('/api/books/:_id',function(req,res){

    Book.getbookbyid(req.params._id,function(err,result){
        if(err)
        {
            throw err;
        }
        else
        {
            res.json(result);
        }

    });

});

app.listen(3000);
console.log("running");






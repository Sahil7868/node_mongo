var mongoose= require('mongoose');

var userSchema = mongoose.Schema({
   
   name:{
       type:String,
       required:true
   },

   create_date:{
    type:Date,
    default:Date.now

   }
});

var Users=module.exports=mongoose.model('Users',userSchema);

// get userSchema


    module.exports.getUser= function(callback,limit){
        Users.find(callback).limit(limit);
    }